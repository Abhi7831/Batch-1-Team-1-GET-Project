import React, { useState, useEffect } from 'react';
import { Navbar, Nav } from 'react-bootstrap';
import { Container, Card } from 'react-bootstrap';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import { Link } from 'react-router-dom';

const UserDashboard = () => {
    const [employee, setEmployee] = useState('');
    const [error, setError] = useState('');
    const { state } = useLocation();


    useEffect(() => {
        const { id, password } = state;
        axios
            .get(`http://localhost:8080/api/v1/employees/${id}`)
            .then((response) => {
                setEmployee(response.data);
            })
            .catch((error) => {
                setError('Error fetching employee details');
            });
    }, []);

    return (
        <div>
            <Navbar variant="dark" style={{background:'linear-gradient(180deg, #007bff, #0047ab)'}} >
                <Container>
                    <Navbar.Brand>Employee Management System</Navbar.Brand>
                    <Nav className="ml-auto">
                        <Link to="/" className="nav-link">Logout</Link>
                    </Nav>
                </Container>
            </Navbar>
            <center>
                <Container>
                    <Card>
                        <Card.Body>
                            <Card.Title>{employee.firstName}</Card.Title>
                            <Card.Text>{employee.lastName}</Card.Text>
                            <Card.Text style={{background:'lightgray'}}>Email: {employee.emailId}</Card.Text>
                            <Card.Text style={{background:'lightgray'}}>Department: {employee.department}</Card.Text>
                            <Card.Text style={{background:'lightgray'}}>Position: {employee.position}</Card.Text>
                            <Card.Text style={{background:'lightgray'}}>Phone Number: {employee.phoneNumber}</Card.Text>
                        </Card.Body>
                    </Card>
                    {error && <p className="text-danger">{error}</p>}
                </Container>
            </center>

        </div>

    );
};

export default UserDashboard;
