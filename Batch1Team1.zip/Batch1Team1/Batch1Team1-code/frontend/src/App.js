import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';
import AddEmployee from './components/AddEmployee';
import ManagerDashboard from './components/ManagerDashboard';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/admin-dashboard" element={<AdminDashboard/>} />
          <Route path="/manager-dashboard" element={<ManagerDashboard/>} />
          <Route path="/add-employee" element={<AddEmployee/>} />
          <Route path="/user-dashboard" element={<UserDashboard/>} />
          <Route path="/" element={<LoginPage/>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
