package net.javaguides.springboot.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Employee;
import net.javaguides.springboot.repository.EmployeeRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	// get all employees
	@GetMapping("/employees")
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAll();
	}

	@GetMapping("employees/check-login/{id}")
	public ResponseEntity<Map<String,String>> checkEmployeeLogin(@PathVariable Long id) {
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee does not exist"));
		Map<String,String> response = new HashMap<>();
		response.put(employee.getPassword(), employee.getRole());
		return ResponseEntity.ok(response);
	}
	
	// create employee rest api
	@PostMapping("/employees")
	public Employee createEmployee(@RequestBody Employee employee) {
		return employeeRepository.save(employee);
	}
	
	// get employee by id rest api
	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
		Employee employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		return ResponseEntity.ok(employee);
	}

		//get employee by id and password
//	@GetMapping("/employees?id=${id}&password=${password}")
//	public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id, String pass){
//		Employee employee=employeeRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Employee does not exist "));
//				if(Objects.equals(employee.getPassword(), pass)){
//					return ResponseEntity.ok(employee);
//				}
//				else{
//					return ResponseEntity.ok(employee); // to be changed!!!!
//				}
//	}

	// validate employee by id rest api
	@GetMapping("/employees/login/{id}")
	public ResponseEntity<String> validateEmployeeById(@PathVariable Long id){
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee does not exist"));
		return ResponseEntity.ok(employee.getRole());
	}

	// get performance by id rest api
	@GetMapping("/employees/{id}/performance")
	public ResponseEntity<Map<Integer,String>> getPerformanceById(@PathVariable Long id){
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee does not exist"));
		Map<Integer,String> response = new HashMap<>();
		response.put(employee.getScore(), employee.getComments());
		return ResponseEntity.ok(response);
	}

	// save performance rest api
	@PutMapping("/employees/{id}/performance")
	public ResponseEntity<Employee> updatePerformance(@PathVariable Long id, @RequestBody Employee employeeDetails){
		Employee employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist "));
		employee.setComments(employeeDetails.getComments());
		employee.setScore(employeeDetails.getScore());
		Employee updatedEmployee = employeeRepository.save(employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	// update employee rest api
	
	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails){
		Employee employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastName(employeeDetails.getLastName());
		employee.setEmailId(employeeDetails.getEmailId());
		employee.setPosition(employeeDetails.getPosition());
		employee.setDepartment(employeeDetails.getDepartment());
		employee.setPhoneNumber(employeeDetails.getPhoneNumber());
		//employee.setPassword(employeeDetails.getPassword());
		employee.setRole(employeeDetails.getRole());
		employee.setComments(employeeDetails.getComments());
		employee.setScore(employeeDetails.getScore());
		Employee updatedEmployee = employeeRepository.save(employee);
		return ResponseEntity.ok(updatedEmployee);
	}
	
	// delete employee rest api
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
		Employee employee = employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		employeeRepository.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	
	
}
